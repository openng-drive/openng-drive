# openNG.drive

openNG.drive is an unofficial launcher for [BeamNG.drive](https://www.beamng.com/game/) on Windows. You pick a car, the weather and a map in one window, click **Start drive**, and the game loads straight into that setup. You can also play with friends over BeamMP, and you get openNG's own pause menu inside the game.

## What's in this zip

| File | What it is |
|---|---|
| `openNG.drive.exe` | The launcher. No installation needed. |
| `BeamMP_Installer.exe` | The official BeamMP installer. Only needed for multiplayer. |
| `README.md` | This file. |

## Before you start

- Windows 10 or 11
- BeamNG.drive installed through Steam
- Microsoft Edge, which comes with Windows (the launcher window runs on it)

## Installation

1. **Unpack the zip.** Right-click `openNG.drive.zip`, choose "Extract All…" and pick where it should go, for example `D:\`. You then have a folder `D:\openNG.drive\` with all the files in it. Don't start the launcher from inside the zip, because it can't save its settings there.

2. **Start openNG.drive.** Double-click `openNG.drive.exe`. The exe isn't signed, so Windows SmartScreen may say "Windows protected your PC" the first time. Click **More info** and then **Run anyway**. You only have to do this once.

3. **Switch the language if you want to.** The launcher starts in English. You can change it to German, French or Russian under **Settings → Launcher → Language**.

4. **Check the game folder.** The launcher looks for BeamNG.drive in your Steam libraries by itself. If it can't find the game, open **Setup → Game folder** and select the folder that contains `BeamNG.drive.exe`.

5. **Install BeamMP (only for multiplayer).** You can do this in either of two ways:
   - In the launcher, open **Multiplayer → Server list**. It finds the installer next to the exe and offers to install it. Click **Install** and finish the BeamMP setup.
   - Or double-click `BeamMP_Installer.exe` yourself and follow the steps.

   The launcher detects BeamMP once it is installed, and the server list unlocks.

6. **Drive.** Under **Singleplayer**, choose a vehicle, the time of day and weather, and a map, then click **Start drive**. In the game, press **Esc** to open the openNG menu.

## Good to know

- Keep `openNG.drive.exe` and `BeamMP_Installer.exe` together in the same folder, so the launcher can find the installer.
- Settings, profiles and cache are saved in the `openNG-data` folder, which appears next to the exe after the first start. Delete it to reset the launcher.
- New versions are offered automatically when you start the launcher.
- While the launcher is open it adds one to the anonymous "driving right now" counter on the website, once every five minutes. No data about you is sent. Switch it off under **Settings → Launcher**.
- Website and downloads: https://openng-drive.github.io/openng-drive/

## Uninstalling

Delete the folder you unpacked. If you installed BeamMP, remove it under Windows **Settings → Apps**.

## Credits

openNG.drive is a fan project by [!"A PRO](https://steamcommunity.com/profiles/76561198871335992/) (Steam). It was built with the help of Claude, an AI assistant made by Anthropic. BeamMP is made by the BeamMP team ([beammp.com](https://beammp.com/)).

It is not affiliated with BeamNG GmbH or BeamMP. BeamNG.drive is a trademark of BeamNG GmbH.
